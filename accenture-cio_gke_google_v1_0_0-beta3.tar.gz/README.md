# Google Cloud Platform: GKE Module

## Overview

Current version = 1.0.0-beta3

The GKE module defines and creates a GKE cluster, node pool, and required components. These components include firewall rules,
IAM roles, IAM service accounts, kubernetes network policies, and other updates to the default settings.

Currently, only one cluster and one node pool will be created per region. When executing the full terraform module, all components necessary will be created and deployed. This includes one cluster and one non-default node pool. 

To deploy to multiple regions, call this cluster sub-module only additional times with different `gke_location` input variables. A standard name for the GKE cluster is computed from the Project ID and a unique random value. There is only one private subnet assigned per the VPC module, this limits the deployment to one cluster per region.

Similarly, the default node pool is immediately removed and a custom node pool is deployed. The custom node pool allows several variables to be configured, but a standard name is used. Multiple node pools in the same region are supported if a non-default node pool name is provided.

If no cluster suffix is provided, a random and unique value will be appended to the end of the cluster name. This same value will be appended to the firewall rules per location. This will provide separation for additional deployments in future releases.

This readme reflects the current status as of release 1.0.0-beta3

## Prerequisites

- Terraform application (this module built & tested with 0.12.18)
- Terraform **`google`** provider (the default provider)
- Terraform **`google-beta`** provider (required for advanced features such as the firewall logging feature)
- Terraform **`kubernetes`** provider (required for replacing network policy YAML files)
- Existing Google Cloud Project-ID
- Existing Google Cloud VPC (acnciotfregistry.accenture.com/accenture-cio/vpc/google)
  - Use VPC module output **`vpcname`** as input variable **`vpc_name`** of GKE module to create a dependency
  - Assumes standard VPC name **`acn-cio-project-vpc`** will be carried between modules
  - **`vpc_name`** GKE input variable is optional, if not specified then **`acn-cio-project-vpc`** will be used
  - VPC must come up with a NAT Router (use the acnciotfregistry.accenture.com/accenture-cio/cloudnatrouter/google module)
- The Google managed Master Nodes cannot be open to all connectivity from the internet
  - The authorized source addresses are **`34.73.6.63/32`** and **`35.233.73.112/32`**
  - These authorized sources may be used by using the GKE build agents
  - The agent pool with these approved agents is named **`5064-Private-Linux-pool`**
  - If another pool, such as the standard pool, is used then deployment of the GKE module will show a failure to install the **`default-deny`** network policy within the GKE cluster
  - This is due to relying on the **`kubernetes`** provider mentioned above to communicate with the newly created cluster endpoint

## Usage (Full Module)

```ruby

module "gke_cluster" {
  # Module source
  source = "acnciotfregistry.accenture.com/accenture-cio/gke/google"

  # Module version
  version = "1.0.0-beta3"

  # Parameters
  project_id                 = "${var.project_id}"
  vpc_name                   = "${module.your_vpc_module.vpcname}"
  gke_cluster_suffix         = "${var.gke_cluster_suffix}"
  gke_location               = "${var.gke_location}"
  gke_instances_preemptible  = "${var.gke_instances_preemptible}"
  gke_instances_type         = "${var.gke_instances_type}"
  gke_initial_worknode_count = "${var.gke_initial_worknode_count}"
  gke_minimal_worknode_count = "${var.gke_minimal_worknode_count}"
  gke_maximum_worknode_count = "${var.gke_maximum_worknode_count}"
  nodepool_name              = "${var.nodepool_name}"
  aqua_token_value           = "${var.aqua_token_value}"
}
```

**USAGE NOTES:**

- This example assumes a VPC is being created in the same file and that variables are defined elsewhere
- `your_vpc_module` is whatever name you've used to create the VPC in the same terraform file
- If your VPC already exists, you will have to setup a `data` call instead of using the `module` reference shown here

---

## Resources created

A standard GKE cluster & custom node pool will be created from sub-modules. Support components for these resources will be created in each sub-module, including access through new roles, service accounts, and firewall rules.

### Input variables

(For this module, only strings are used for all input variables including the count options.)

- project_id **[Required]**
: "The GCP ID of the project for which a GKE cluster to be created."
- vpc_name *[Optional]*
: "The name of the deployed VPC. (lowercase with no space) [default = 'acn-cio-project-vpc']
- gke_cluster_suffix *[Optional]*
: "User suffix to be appended to the standard name [default = '']"
- gke_location *[Optional]*
: "The GCP region for deployment of a GKE cluster. (lowercase with no space) [default = 'us-east1']"
- gke_instances_preemptible *[Optional]*
: "Preemptible VMs last a maximum of 24 hours and provide no availability guarantees. 1: Last for 24 hours. 0: long lived VMs [default = '1']"
- gke_instances_type *[Optional]*
: "The instance type (lowercase with no space) [default = 'n1-standard-2']"
- gke_initial_worknode_count *[Optional]*
: "The initial node count [default = '1']"
- gke_minimal_worknode_count *[Optional]*
: "The minimal node count [default = '1']"
- gke_maximum_worknode_count *[Optional]*
: "The maximum node count [default = '1']"
- nodepool_name *[Optional]*
: "Enter the Node Pool desired name [default = 'primary-pool']"
- aqua_token_value *[Optional]*
: "The sensitive token microenforcer running in the containers requires to be able to report to Aqua [default = '']"

**NOTE**: 

- The VPC module currently deploys the required private-subnet to only the following regions:  
  > us-central1, us-east1, europe-west1, europe-west2, asia-northeast1, asia-south1  
  Please choose one of these for the `gke_location` if other than us-east1 is needed

- To provide sensitive value for variable aqua_token_value, it's safe to first add the variable in AzureDevOps (i.e. AQUA_TOKEN_VALUE) and change it to secret variable type. 
  Then declare environment variable named TF_VAR_ followed by the name of terraform variable aqua_token_value. Terraform searches the environment of its own process for environment
  variables named TF_VAR_. Below is example of how to provide value to aqua_token_value via environment variable in bash before running terraform commands:
  > export TF_VAR_aqua_token_value=$(AQUA_TOKEN_VALUE)
---

## Example

### Input

This example assumes default settings except the Maximum Work Node Count. Project ID is the only required variable.
It is also assumes that the standard VPC already exists for deployment of a GKE cluster into standard private subnets.

``` ruby
module "sample_gke_cluster" {
  source                     = "acnciotfregistry.accenture.com/accenture-cio/gke/google"
  version                    = "1.0.0-3"
  project_id                 = "npd-5064-computetest-88332e97"
  gke_maximum_worknode_count = "3"
  gke_cluster_suffix         = "myapp"
  aqua_token_value           = "${var.aqua_token_value}"
}
```

### Results

#### **Created**

- Kubernetes cluster
: "k8s-5064-npd-myapp"
- Kubernetes node pool
: "primary-pool"
- Kubernetes network policy
: "default-deny"
- IAM service accounts
: "gke_nodes_account", "gcr_aqua_account"
- IAM service account permissions
: "monitoring.viewer", "storage_objectviewer", "objectviewer", "monitoringmetricwriter", "logwriter"
- Cluster firewall policies
: "node_master_egress", "node_egress", "aqua_egress", "kubelet_egress"
- Kubernetes secret
: "aqua_token_sbx" or "aqua_token_npd" or "aqua_token_prd" depends on environment (prefix of project_id)

(the firewall policies are created per region/location and also include a 2-byte randomly assigned value which is unique)

#### **Cluster details**

- Horizontal pod autoscaling
: Enabled
- HTTP/HTTPS load balancing
: Enabled
- Location
: "us-east1" (Region)
- Kubernetes master version
: Default
- Kubernetes node version
: Default
- Default node pool
: Deleted
- Network policy provider
: CALICO
- VPC
: "acn-cio-project-vpc"
- Zones
: auto-assigned
- Enable private nodes
: True
- Primary node subnet
: "us-east1-private-subnet"
- Master endpoint
: auto-assigned
- Kubernetes secret
: auto-created for different envioronment (sbx/npd/prd)

#### **Node Pool details**

- Autoscaling Minimal Node Count
: 1
- Autoscaling Maximum Node Count
: 3
- Machine type
: "n1-standard-2"
- Location
: "us-east1"
- Preemptible
: True
- Auto repair
: True
- Auto upgrade
: True

### Output

- Module version
: `tf_module_version`
- Module name
: `tf_module_name`
- GKE Cluster Name
: `gke_cluster_name`
- GKE Master Node Endpoint
: `gke_endpoint`
- GKE Cluster CA Certificate
: `gke_cluster_ca_cert`
- GKE Master Node version
: `gke_master_version`
- Service Account email address for the AquaSec scanning account
: `service_account_aqua_address`

## Usage (Cluster Sub-Module)

To avoid a conflict in recreating the system-wide components such as service accounts, the email addresses used to identify the existing service accounts must be provided. This email address is available from Terraform in the output from the prior execution of this whole GKE module. When originally created, this value is automatically passed to the sub-module and is therefore only required when additional nodes will be created. In this case, the additional node pool is created as a direct requirement that each cluster must have a node pool.

```ruby

module "gke_cluster_two" {
  # Module source
  source = "acnciotfregistry.accenture.com/accenture-cio/gke/google//modules/gke-cluster"

  # Module version
  version = "1.0.0-beta3"

  # Parameters
  project_id                    = "${var.project_id}"
  vpc_name                      = "${module.your_vpc_module.vpcname}"
  gke_cluster_suffix            = "${var.gke_cluster_suffix}"
  gke_location                  = "${var.gke_location}"
  gke_instances_preemptible     = "${var.gke_instances_preemptible}"
  gke_instances_type            = "${var.gke_instances_type}"
  gke_initial_worknode_count    = "${var.gke_initial_worknode_count}"
  gke_minimal_worknode_count    = "${var.gke_minimal_worknode_count}"
  gke_maximum_worknode_count    = "${var.gke_maximum_worknode_count}"
  nodepool_name                 = "${var.nodepool_name}"
  aqua_token_value              = "${var.aqua_token_value}"
}
```

### New Input Variables (Cluster)

These new input variables are available as output from the main module.

- aqua_token_value *[Optional]*
: "The sensitive token microenforcer running in the containers requires to be able to report to Aqua [default = '']"

**NOTE**: 
- To provide sensitive value for variable aqua_token_value, it's safe to first add the variable in AzureDevOps (i.e. AQUA_TOKEN_VALUE) and change it to secret variable type. 
  Then declare environment variable named TF_VAR_ followed by the name of terraform variable aqua_token_value. Terraform searches the environment of its own process for environment
  variables named TF_VAR_. Below is example of how to provide value to aqua_token_value via environment variable in bash:
  > export TF_VAR_aqua_token_value=$(AQUA_TOKEN_VALUE)

### Output (Cluster Sub-Module)

- Module version
: `tf_module_version`
- Module name
: `tf_module_name`
- GKE Cluster Name
: `cluster_name`
- GKE Master Node Endpoint
: `gke_endpoint`
- GKE Cluster CA Certificate
: `cluster_ca_cert`
- GKE Master Node version
: `master_version`

## Usage (Nodepool Sub-Module)

To avoid a conflict in recreating the system-wide components such as service accounts, the email addresses used to identify the existing service accounts must be provided. This email address is available from Terraform in the output from the prior execution of this whole GKE module. When originally created, this value is automatically passed to the sub-module and is therefore only required when additional nodes will be created. In this case, only the additional node pool is being created. 

A tag is created in the nodepool referencing the initial value of the GKE Cluster master nodes. This is primarily created for documentation and as a method to place a dependency on the custom node pool so it will be created after the initial cluster is created and the default node pool is removed.

```ruby

module "gke_nodepool" {
  # Module source
  source = "acnciotfregistry.accenture.com/accenture-cio/gke/google//modules/gke-nodepool"

  # Module version
  version = "1.0.0-beta3"

  # Parameters
  project_id                    = "${var.project_id}"
  cluster_name                  = "${var.cluster_name}"
  gke_location                  = "${var.gke_location}"
  service_account_nodes_address = "${var.service_account_nodes_address}"
  gke_instances_preemptible     = "${var.gke_instances_preemptible}"
  gke_instances_type            = "${var.gke_instances_type}"
  gke_initial_worknode_count    = "${var.gke_initial_worknode_count}"
  gke_minimal_worknode_count    = "${var.gke_minimal_worknode_count}"
  gke_maximum_worknode_count    = "${var.gke_maximum_worknode_count}"
  nodepool_name                 = "${var.nodepool_name}"
  master_version_tag            = "${var.master_version}"
}
```

### New Input Variables (Nodepool)

These new input variables are available as output from the main module or cluster sub-module.

- cluster_name *[Required]*
: "The of the existing cluster"
- service_account_nodes_address *[Required]*
: "The service account email address created for GKE cluster nodes (this one is resolved and passed by the gke-cluster submodule)"
- master_version_tag *[Required]*
: "An initial value of the GKE cluster version the nodes will be associated with [not used after initial setup]"

### Output (Nodepool Sub-Module)

- Module version
: `tf_module_version`
- Module name
: `tf_module_name`

## Usage (GKE Service Sub-Module)

The GKE Service sub module support <strong>terraform 0.12</strong> only. Currently tested out in 0.12.18.

The GKE Service module is a combination of kubernetes_ingress, kubernetes_deployment and kubernetes_service with 'micro service' concept:
 - A Deployment ensures that a specified number of pod “replicas” are running at any one time. Multiple deployments is supported for now.
 - A Ingress is a collection of rules that allow inbound connections to reach the endpoints defined by a backend. An Ingress can be configured to give services externally-reachable urls, load balance traffic, terminate SSL, offer name based virtual hosting etc. Multiple ingress http rule paths is supported for now, which allows incoming urls matching the different paths are forwarded to the different backends.
 - A Service is an abstraction which defines a logical set of pods and a policy by which to access them - sometimes called a micro-service. There are multiple types that determine how the service is exposed. For example, ExternalName, ClusterIP, NodePort, and LoadBalancer. <strong>NodePort</strong> is the only one support for now. Multiple services is supported for now.

**NOTE**: 
- For kubernetes_deployment, aqua-token is automatically populate as environment variable in all containers from this release.

main.tf:

```ruby

locals {
  dockerconfigjson = jsonencode({
    "auths" = {
      "https://gcr.io" = {
        email    = "sa-npd-5064-computetest-88332e@npd-5064-computetest-88332e97.iam.gserviceaccount.com"
        username = "_json_key"
        password = trimspace(file("keyfile.json"))
        auth     = base64encode(join(":", list("_json_key", trimspace(file(pathexpand("keyfile.json"))))))
      }
    }
  })
}

provider "google" {
  credentials = file(var.gcp_credential_path)
  project     = var.project_id
  region      = var.region
}

provider "google-beta" {
  credentials = file(var.gcp_credential_path)
  project     = var.project_id
  region      = var.region
}

data "google_client_config" "default" {}

provider "kubernetes" {
  version          = "1.9.0"
  load_config_file = false
  host             = "1.2.3.4" # Change to your GKE cluster endpoint
  token            = "data.google_client_config.default.access_token"
  insecure = "1"
}

module "gke_ssl" {

  # Module source
  source                      = "acnciotfregistry.accenture.com/accenture-cio/gke/google//modules/gke-ssl"

  # Module version
  version                     = "1.0.0-beta3"

  # Parameters 
  compute_sslcert_certificate = "#{COMPUTE_SSLCERT_CERTIFICATE}#"
  compute_sslcert_name        = "#{COMPUTE_SSLCERT_NAME}#"
  compute_sslcert_private_key = "#{COMPUTE_SSLCERT_PRIVATE_KEY}#"

}

module "gcp_gke_service" {
  # Module source
  source                 = "acnciotfregistry.accenture.com/accenture-cio/gke/google//modules/gke-service"
  
  # Module version
  version                = "1.0.0-beta3"

  # Parameters
  kubernetes_ingresses   = var.kubernetes_ingresses
  kubernetes_services    = var.kubernetes_services
  kubernetes_deployments = var.kubernetes_deployments
  kubernetes_secrets = {
    secretname1 = {
      metadata = {
        labels = {
            app    = "applicationName1"
        }
      }
      secret_type = "kubernetes.io/dockerconfigjson"
      secret_data = {
        ".dockerconfigjson" = local.dockerconfigjson
      }
    }
    secretname2 = {
      metadata = {
        labels = {
            app    = "applicationName2"
        }
      }
      secret_type = "kubernetes.io/dockerconfigjson"
      secret_data = {
        ".dockerconfigjson" = local.dockerconfigjson
      }
    }
    secretname3 = {
      metadata = {
        labels = {
            app    = "app-secret"
        }
      }
      secret_type = "Opaque"
      secret_data = {
        "mykey"  = "myvalue"
        "mykey2" = "myvalue2"
      }
    }
  }
}
```

### Input Variables
- `application_name` *[Required]*
: "The Name of application. Also a part of ingress service name: {application_name}-ingress"
- `kubernetes_ingress_http_rule_paths` *[Optional]*
: "Kubernets Ingress http rule path list array, which is list array of path regex associated with a backend. Incoming urls matching the path are forwarded to the backend. Default is {}"
- `kubernetes_services` *[Optional]*
: "Map of NodePort type Kubernets services. Default is {}"
- `kubernetes_deployments` *[Optional]*
: "Map of Kubernets deployments. Default is {}"
- `kubernetes_secrets` *[Optional]*
: "Map of Kubernetes sercrets. Default is {}"

### Full sample of Input Variables tfvars files

A tfvars file that persist full variable values. Below are tfvars files by resource type: one ingress with two rule paths (could be multiple ingresses), two services, two deployments. You could also combine them into one tfvar file. Usually the values are different as per environment:

global.tfvars:

``` ruby
project_id       = "npd-5064-computetest-88332e97"
region           = "us-east1"
```

kubernetes_ingresses.tfvars:

``` ruby
kubernetes_ingresses = {
  spa-app-name-ingress1 = {
    metadata = {
      # Pass labels = {} for optional arg 
      labels = { 
        app = "MyIngress"
      }
      # Pass annotations = {} for optional arg 
      annotations = {
        "kubernetes.io/ingress.allow-http" = "false" # Annotation to disable HTTP and only leave HTTPS. Requires the two below annotations:
        "kubernetes.io/ingress.global-static-ip-name" = "ingress-#{ENVIRONMENT}#-ipv4-global-external" # Static IP reserved by the globalipreserve module
      }
    }
    spec = {
      # Pass backend = {} for optional arg
      backend = {}
      # Pass rule = {} for optional arg
      rule = {
          http = [
              {
                #Backend defines the referenced service endpoint to which the traffic will be forwarded to
                backend = {
                  #Specifies the name of the referenced service.
                  service_name = "service-1"
                  #Specifies the port of the referenced service.
                  service_port = 8080
                }
                #A string or an extended POSIX regular expression as defined by IEEE Std 1003.1, (i.e this follows the egrep/unix syntax, not the perl syntax) matched against the path of an incoming request. 
                #Currently it can contain characters disallowed from the conventional \"path\" part of a URL as defined by RFC 3986. Paths must begin with a '/'. If unspecified, the path defaults to a catch all sending traffic to the backend.
                path = "/app1"
              },
              {
                backend = {
                  service_name = "service-2"
                  service_port = 8080
                }
                path = "/app2"
              }
          ]
      }
      # Pass tls = {} for optional arg
      tls = {
        secret_name = "#{COMPUTE_SSLCERT_NAME}#"
      }
    }
  }
}
```

kubernetes_services.tfvars:

``` ruby
kubernetes_services = {
  #Name of the service, must be unique. Cannot be updated
  service-1 = {
    metadata = {
        # Pass labels = {} for optional arg 
        labels = {
            app    = "applicationName1"
            role   = "service"
        }
    }
    spec = {
        # Route service traffic to pods with label keys and values matching this selector
        # Pass selector = {} for optional arg 
        selector = {
            app = "applicationName1"
        }
        port = {
            #The name of this port within the service 
            name = "portname1"
            #The port that will be exposed by this service
            port = 8080
            #Number or name of the port to access on the pods targeted by the service. Number must be in the range 1 to 65535.
            target_port = 8080
        }
        type = "NodePort"
    }
  }
  service-2 = {
    metadata = {
        labels = {
            app    = "applicationName2"
            role   = "service"
        }
    }
    spec = {
        selector = {
            app = "applicationName2"
        }
        port = {
            name = "portname1"
            port = 8080
            target_port = 8080
        }
        type = "NodePort"
    }
  }
}
```
kubernetes_deployments.tfvars:

``` ruby
kubernetes_deployments = {
  deployment-1 = {
    metadata = {
        labels = {
            test = "applicationName1"
            app  = "applicationName1"
        }
    }

    spec = {
      # The number of desired replicas
      # If replicas not passed, default is 1
      replicas = 2
      # Pass selector = {} for optional arg 
      selector = {
        match_labels = {
          #A label query (with key 'app') over pods that should match the Replicas count. Label keys and values that must match in order to be controlled by this deployment. Must match labels (spec_template_metadata_labels_app)
          app = "applicationName1"
        }
      }
      template = {
        metadata = {
          # Pass labels = {} for optional arg 
          labels = {
            #Map of string keys and values (with key 'app') that can be used to organize and categorize (scope and select) the deployment. Must match selector (spec_selector_match_labels_app)
            app = "applicationName1"
          }
        }
        spec = {
          container = {
            #Docker image name
            image = "gcr.io/npd-5064-computetest-88332e97/spa:0.1.17769"
            #Name of the container specified as a DNS_LABEL. Each container in a pod must have a unique name (DNS_LABEL). Cannot be updated
            name  = "spa"
            # Pass resources = {} for optional arg 
            resources = {
              limits = {
                #Maximum amount of compute resources cpu allowed
                cpu    = "0.5"
                #Maximum amount of compute resources memory allowed
                memory = "512Mi"
              }
              requests = {
                #Minimum amount of compute resources cpu required
                cpu    = "250m"
                #Minimum amount of compute resources memory required
                memory = "50Mi"
              }
            }
            port = {
              #Port to expose from the container
              container_port = 8080
            }
            # Have kubernetes secrets exposed to the containers
            secrets = "secretname3"
            # Pass readiness_probe = {} for optional arg 
            readiness_probe = {
              http_get = {
                #Scheme to use for connecting to the host. Defaults to HTTP
                scheme = "HTTP"
                #Path to access on the HTTP server
                path   = "/ready"
                #Name or number of the port to access on the container. Number must be in the range 1 to 65535
                port   = 8080
              }
              #Number of seconds after the container has started before liveness probes are initiated
              initial_delay_seconds = 20
              #Number of seconds after which the probe times out
              timeout_seconds       = 10
              #How often (in seconds) to perform the readiness_probe
              period_seconds        = 30
              #Minimum consecutive failures for the probe to be considered failed after having succeeded
              failure_threshold     = 5
            }
            # Pass liveness_probe = {} for optional arg 
            liveness_probe = {
              http_get = {
                #Scheme to use for connecting to the host. Defaults to HTTP
                scheme = "HTTP"
                #Path to access on the HTTP server
                path = "/ready"
                #Name or number of the port to access on the container. Number must be in the range 1 to 65535
                port = 8080
              }
              #Number of seconds after the container has started before liveness probes are initiated
              initial_delay_seconds = 20
              #Number of seconds after which the probe times out
              timeout_seconds       = 10
              #How often (in seconds) to perform the liveness_probe
              period_seconds        = 30
              #Minimum consecutive failures for the probe to be considered failed after having succeeded.
              failure_threshold     = 5
            }
          }
        }
      }
    }
    #The following Timeout configuration options are available for the kubernetes_deployment resource:
    timeouts = {
      create = "60m"
      update = "60m"
      delete = "60m"
    }
  },
  deployment-2 = {
      metadata = {
          labels = {
              test = "applicationName2"
              app  = "applicationName2"
          }
      }

      spec = {
        replicas = 2
        selector = {
          match_labels = {
            app = "applicationName2"
          }
        }
        template = {
          metadata = {
            labels = {
              app = "applicationName2"
            }
          }
          spec = {
            container = {
              image = "gcr.io/npd-5064-computetest-88332e97/spa:0.1.17769"
              name  = "spa"
              resources = {
                limits = {
                  cpu    = "0.5"
                  memory = "512Mi"
                }
                requests = {
                  cpu    = "250m"
                  memory = "50Mi"
                }
              }
              port = {
                container_port = 8080
              }
              secrets = "secretname3"
              readiness_probe = {
                http_get = {
                  scheme = "HTTP"
                  path   = "/ready"
                  port   = 8080
                }
                initial_delay_seconds = 20
                timeout_seconds       = 10
                period_seconds        = 30
                failure_threshold     = 5
              }
              liveness_probe = {
                http_get = {
                  scheme = "HTTP"
                  path = "/ready"
                  port = 8080
                }
                initial_delay_seconds = 20
                timeout_seconds       = 10
                period_seconds        = 30
                failure_threshold     = 5
              }
            }
          }
        }
      }
      timeouts = {
        create = "60m"
        update = "60m"
        delete = "60m"
      }
    }
  }
```

Tipically the terraform commands to use the gke-service module:

``` ruby
terraform init
terraform plan -input=false -out=tfplan.tfplan -var-file=kubernetes_deployments.tfvars -var-file=kubernetes_ingresses.tfvars  -var-file=kubernetes_services.tfvars -var-file=global.tfvars -no-color -var gcp_credential_path=keyfile.json
terraform apply -no-color -auto-approve tfplan.tfplan
terraform destroy -lock=true  -lock-timeout=15m  -input=false  -no-color  -auto-approve -var-file=env.tfvars

```


### Output (GKE Service Sub-Module)

- Module version
: `tf_module_version`
- Module name
: `tf_module_name`
- Ingress endpoint ip address
: `ingress_address`


# Changelog

| <b>Version </b>| <b>Change Summary </b>|
|----------------|-----------------------------|
| 1.0.0-beta3    | - New key naming convention: <project-id>-2-ky (previously it was <project-id>-1-ky). |
| 1.0.0-beta2    | - Added support for kubernetes_deployments.*.spec.template.spec.container.secrets to map Kubernetes secrets/variables. This can be a list of strings or a single string for a single secret. |
| 1.0.0-beta1    | - New GKE submodule: gke-ssl. Including SSL certificates with kubernetes secrets. |
|                | - Improved documentation |
| 0.1.0-beta21   | - Added back secrets support included TLS certificates |
|                | - Migrated from gke-nodes-sa to runtime service account |
|                | - Simplified cluster interface (runtime service account is now resolved in the cluster) |
| 0.1.0-beta20   | - Force Kubernetes to download always the newest image |
| 0.1.0-beta19   | - Added the Kubernetes Service Account for the Workload Identity |
|                | - Added the binding for the Kubernetes Service Account to the GKE Nodes Service Account |
| 0.1.0-beta18   | - Use the ENVIRONMENT variable now for the static IP reservation |
|                | - Updated SPA demo app in the service |
|                | - Added AirID label to the cluster to comply with IS control 335 |
|                | - Removed unsused features image_pull_secrets & tls in secrets |
|                | - Improved documentation |
| 0.1.0-beta17   |Removed workload_metadata_config from the nodepool, since its being deprecated. |
|                |Updated documentation on how to consume static IP (with the globalipreserve module) & SSL certificates (with the compute_sslcert_name module) |
|                |Added 'workload_identity_config' support to replace workload_metadata_config. |
|                |Added surge support in the nodepool. |
|                |Updated demo to spa:0.1.17769 |
|                |Fixed integration tests |
|                |Moved gke-nodes-sa creation to the project bootstrap |
| 0.1.0-beta16   |Change GKE module to add aqua-token as kubernetes secret for sbx, npd and prd. |
|                |Change GKE service submodule to populate environment variable aqua-token in the kubernetes deployment container. |
| 0.1.0-beta15   |Change by addingg support pass empty value for below optional arguments for <b>kubernetes_secret</b> in gke-service sub module: |
|                |<ul><li>metadata.labels</li><li>data</li><li>type</li></ul> |
|                |Change by addingg support pass empty value for below optional arguments for <b>kubernetes_ingress</b> in gke-service sub module: |
|                |<ul><li>metadata.labels</li><li>metadata.annotations</li><li>spec.backends</li><li>spec.rule</li><li>spec.tls</li></ul> |
|                |Change by ddingg support pass empty value for below optional arguments for <b>kubernetes_deployment</b> in gke-service sub module: |
|                |<ul><li>metadata.labels</li><li>spec.replicas</li><li>spec.selector</li><li>spec.template.metadata.labels</li><li>spec.template.spec.container.resources</li><li>spec.template.spec.container.port</li><li>spec.template.spec.container.readines_probe</li><li>spec.template.spec.container.liveness_probe</li><li>spec.template.spec.image_pull_secrets</li><li>timeouts</li></ul> |
|                |Change by Adding support pass empty value for below optional arguments for <b>kubernetes_service</b> in gke-service sub module: |
|                |<ul><li>metadata.labels</li><li>spec.selector</li></ul> |
| 0.1.0-beta14   |Change GKE submodule: gke-service. Adding support pass empty/unset image_pull_secrets in kubernetes_deployments in the event of no need to provide a secret for the image to pull. |
| 0.1.0-beta13   |Add creating multiple kubernetes_secret in gke-service sub module |
|                |Upgrade terraform 0.12 support for the GKE module as well as sub modules |
|                |Change type of kubernetes_service from LoadBalancer to NodePort to remove duplicate external ip and make health check fast for gke-service sub module |
|                |Change kubernetes_service to support multiple services for gke-service sub module |
|                |Change kubernetes_ingress to support multiple ingresses and multiple http rules that allow inbound connections to backends for gke-service sub module |
|                |Change kubernetes_deployment to support multiple deployments for gke-service sub module |
| 0.1.0-beta12   |New GKE submodule: gke-service. Including kubernetes ingress, kubernetes deployment and kubernetes service, to allow app team deploy their application. |
| 0.1.0-beta11   |Deleted the /onboarding directory entirely: removing scripts for per-project AquaSec credentials for scanning. |
|                |Updated main.tf in the root directory to remove code that built Aqua service account, assigned permissions, and save key to file |
| 0.1.0-beta10   |New variables: |
|                |<ul><li><b>gke_cluster_suffix</b> to support multiple clusters per region</li><li><b>nodepool_name</b> to support multiple node pools per cluster</li></ul> |
|                |New output: Service account email addresses needed for separate deployment of secondary clusters or node pools |
|                |Kubernetes provider necessary for default-deny network policy set to version 1.09 after problems found in version 1.10 |
|                |Moved service accounts and permission updates from the Cluster module to the root level |
|                |Moved Nodepool deployment from the root level to the Cluster module |
|                |Cluster module calculates a unique cluster name instead of creating a standard cluster name |
|                |<ul><li>If gke_cluster_suffix is provided, it will be appended to the end of the previous standard cluster name</li><li>If gke_cluster_suffix does not exist, a random 2-byte hex digit will be appended instead</li></ul> |
|                |If nodepool_name is provided it will be used for the pool, otherwise the previous standard will be used as a default |
|                |Necessary firewall rules updated with region they're applied and the random identifier potentially also used as a cluster suffix |
|                |Default for pre-emptible changed to long-lived ('0') due to blueprint requirement |
|                |Updated logging and monitoring as classic StackDriver is becoming obsolete in newer GKE versions |
| 0.1.0-beta9    |Fix typo in aqua_onboarding.sh |
| 0.1.0-beta8    |Fix empty onboarding folder after publishing to module registry |
| 0.1.0-beta7    |Removed unnecessary kubernetes sample yaml files |
| 0.1.0-beta6    |Updates to onboarding scripts for integration with AquaSec for scanning |
| 0.1.0-beta5    |Updates to onboarding scripts for integration with AquaSec for scanning |
| 0.1.0-beta4    |Updated top level output.tf to include sub-module gke-cluster output, including: |
|                |<ul><li><b>gke_cluster_name</b></li><li><b>gke_endpoint</b></li><li><b>gke_cluster_ca_cert</b></li><li><b>gke_master_version</b></li></ul> |
| 0.1.0-beta3    |Saved GCR Aqua service account as local file for export |
|                |Updated README.md with greater explanation for required build agent pool pipelines |
| 0.1.0-beta2    |Changed <b>vpc_name</b> from locally defined to optional input variable (allows VPC module output to act as input) |
|                |Updated README.md to explain how to use new <b>vpc_name</b> variable |
| 0.1.0-beta     |Updates to dedicated source addresses for allowed Master Node access and pipeline execution required agent pool |
| 0.1.0-alpha1   |Version bump |
| 0.1.0-alpha    |Initial commit |
